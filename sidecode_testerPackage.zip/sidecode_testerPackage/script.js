function main(){
  const queryTag = 'a[href^=https://www.google.com/]';
  const line = document.querySelectorAll(queryTag);
  line[0].href="http://localhost:8000/code.html";
}
